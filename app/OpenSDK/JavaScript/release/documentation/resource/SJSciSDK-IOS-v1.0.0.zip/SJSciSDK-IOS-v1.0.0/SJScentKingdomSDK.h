//
//  SJScentKingdomSDK.h
//  SJScentKingdomSDK
//
//  Created by baolicheng on 2016/12/19.
//  Copyright © 2016年 RenRenFenQi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SJScentking.h"
// 返回码
enum SrErrorCode {
    SEC_NONE = 0,// 无状态
    SEC_SUCCESS = 10000,// 任务完成
    SEC_ACCEPT = 10001,// 接受任务
    SEC_ERROR = 20000, // 出现错误
    SEC_REJECT = 20001// 拒绝任务
};
