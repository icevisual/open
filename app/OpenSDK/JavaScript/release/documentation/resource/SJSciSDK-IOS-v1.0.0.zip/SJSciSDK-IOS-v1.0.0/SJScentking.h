//
//  SJScentking.h
//  SJScentKingdomSDK
//
//  Created by baolicheng on 2016/12/21.
//  Copyright © 2016年 RenRenFenQi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFNetworking.h>
#import <CoreBluetooth/CoreBluetooth.h>
//添加WiFi设备成功通知
//#define SJAddDevicesSuccessNotify @"SJAddDevicesSuccessNotify"
////绑定WiFi设备列表通知
//#define SJListBindedDevicesNotify @"SJListBindedDevicesNotify"
////解绑设备成功通知
//#define SJRemoveDevicesNotify @"SJRemoveDevicesNotify"
//蓝牙返回数据通知
#define BluetoothDeliveryDataNotify @"BluetoothDeliverryDataNotify"
//蓝牙已打开通知
#define kBluetoothPowerOnNotify @"KBluetoothPowerOnNotify"
//蓝牙未打开通知
#define kBluetoothPowerOffNotify @"KBluetoothPowerOffNotify"
//
#define LastConnectDeviceNameKey @"LastConnectDeviceNameKey"
//搜索蓝牙设备完成通知
#define SearchBluetoothDevicesComplete @"SearchBluetoothDevicesComplete"
//WIFI设备连接成功通知
#define ConnectWiFiSucess @"connectWiFiSucess"
//WiFi返回数据通知
#define WiFiDeliveryDataNotify @"wifiDeliverryDataNotify"
//
#define WiFiDeBugDataNotify @"wifiDeBugDataNotify"
//
#define OnStartScanBluetooth @"OnStartScanBluetooth"
//蓝牙连接中通知
#define OnCallbackBluetoothPowerOff @"OnCallbackBluetoothPowerOff"
//
#define OnCallbackScanBluetoothTimeout @"OnCallbackScanBluetoothTimeout"
//
#define OnCallbackBluetoothDisconnected @"OnCallbackBluetoothDisconnected"
//蓝牙连接中通知
#define OnStartConnectToBluetooth @"OnStartConnectToBluetooth"
//蓝牙设备已连接通知
#define OnCallbackConnectToBluetoothSuccessfully @"OnCallbackConnectToBluetoothSuccessfully"
//蓝牙设备连接超时通知
#define OnCallbackConnectToBluetoothTimeout @"OnCallbackConnectToBluetoothTimeout"


typedef void (^ApiSuccessCallback)(NSURLSessionDataTask *task, id responseObject);
typedef void (^ApiFailedCallback)(NSURLSessionDataTask *task, NSError *error);
//弹出秘钥窗口代理
@protocol ClickTureDelegate <NSObject>
- (void)clickTure:(NSString *)secretKey;
@end

@interface SJScentking : NSObject

@property (nonatomic,weak)id<ClickTureDelegate>delegate;
/**
 *
 * 弹出秘钥窗口
 *
 **/
- (void)SecretKeyAlertWithSelfVC:(id)selfVC;
/**
 *
 * 检测设备是否存在
 *
 *  devicesName 设备名
 **/
- (void)TestEquipmentWithDevicesName:(NSString *)devicesName success:(ApiSuccessCallback)success failed:(ApiFailedCallback)failed;
/**
 *
 * 添加设备
 *
 *  devicesName 设备名
 *  secretKey
 *
 **/
- (void)addSevicesGetDataDevicesName:(NSString *)devicesName SecretKey:(NSString *)secretKey success:(ApiSuccessCallback)success failed:(ApiFailedCallback)failed;
/**
 *
 * 请求已绑定设备
 *
 **/
- (void)listBindedDevicesSuccess:(ApiSuccessCallback)success failed:(ApiFailedCallback)failed;
/**
 *
 * 解绑设备
 *
 *  accessKey
 **/
- (void)removeAccessKey:(NSString *)accessKey success:(ApiSuccessCallback)success failed:(ApiFailedCallback)failed;
/**
 *
 * 注册搜索蓝牙设备
 *
 **/
- (void)regiterSearchBlue;
/**
 *
 * 搜索蓝牙设备
 *
 **/
- (void)startBluetoothDevice;
/**
 *
 * 停止搜索
 *
 **/
- (void)stopScan;
/**
 *
 * 蓝牙连接
 *
 **/
- (void)connectBlue:(CBPeripheral *)peripheral title:(NSString *)title RSIS:(NSNumber *)RSIS;
/**
 *
 * 蓝牙断开连接
 *
 **/
- (void)disBlueConnect;
/**
 *
 * WiFi连接
 *
 **/
- (void)connectWiFi:(NSString *)deviceAccess title:(NSString *)title;
/**
 *
 * WiFi断开连接
 *
 **/
- (void)disWiFiConnect;
/**
 *
 * 蓝牙获取设备模型信息
 *
 **/
-(void)getDeviceModelInformationToBlue;
/**
 *
 * 物联网获取设备模型信息
 *
 **/
-(void)getDeviceModelInformationToWiFiWithDeviceAccess:(NSString *)deviceAccess;
/**
 *
 * 蓝牙获取WiFi列表
 *
 **/
- (void)getWiFiListToBlue;
/**
 *
 * 通过蓝牙配置设备Wi-Fi
 *
 *  name  wifi SSID
 *  pwd   wifi密码
 **/
- (void)setDevWifiWithName:(NSString *)name Pwd:(NSString *)pwd;
/**
 *
 * 通过蓝牙设置控件属性请求  说明: attr 对应的 '开关'属性名为: @"status"、'进度条'属性名为: @"value"、'方向'的属性名为: @"angle"
 *
 *  identity 控件标识符，指明设置的控件
 *  attr     控件属性名，指明要设置的属性
 *  value    属性值
 **/
- (void)setControlAttrToBlueWithIdentity:(NSString *)identity Attr:(NSString *)attr value:(NSString *)value;
/**
 *
 * 通过物联网设置控件属性请求  说明: attr 对应的 '开关'属性名为: @"status"、'进度条'属性名为: @"value"、'方向'的属性名为: @"angle"
 *
 *  identity 控件标识符，指明设置的控件
 *  attr     控件属性名，指明要设置的属性
 *  value    属性值
 *  topic    接收设备的订阅号
 **/
- (void)setControlAttrToWiFiWithIdentity:(NSString *)identity Attr:(NSString *)attr value:(NSString *)value toTopic:(NSString *)topic;
- (NSString *)totpPassword:(NSString *)Str;
/**
 *
 * 蓝牙发送指令
 *
 *  msgStr  16进制字符串
 **/
- (void)sendBlueDataWithStr:(NSString *)msgStr;
/**
 *
 * 物联网发送指令
 *
 *  msgStr  16进制字符串
 *  topic  接收设备的订阅号
 **/
- (void)sendWIFIDataWithStr:(NSString *)msgStr Topic:(NSString *)topic;
/**
 *
 *  获取搜索到的所有智能设备
 *
 *  @return 智能设备列表
 */
-(NSArray *)returnAllScanPeripherals;
/**
 *
 *  获取搜索到的所有智能设备名字
 *
 *  @return 智能设备名字列表
 */
-(NSArray *)returnAllScanPeripheralNames;
/**
 *
 *  获取搜索到的所有智能设备信号
 *
 *  @return 智能设备信号列表
 */
-(NSArray *)returnAllScanPeripheralSignals;
/**
 *
 *  返回当前连接的设备
 *
 *  @return 当前连接的设备
 */
-(CBPeripheral *)returnConnectedPeripheral;
/**
 *
 *  蓝牙是否连接状态
 *
 *  @return YES/是 NO/否
 */
-(BOOL)isConnected;
@end
